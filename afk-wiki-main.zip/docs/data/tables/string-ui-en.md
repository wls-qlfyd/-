---
title: "StringUI_en"
layout: data
description: "StringUI_en 원본 기록 54줄입니다."
permalink: /docs/data/tables/string-ui-en/
data_file: "/assets/data/raw/string-ui-en.json"
data_asset: "FBDataStringUI_en"
data_schema: "FBDataStringUI"
data_rows: 54
data_category: "문자열"
data_fields: ["id","key","value"]
data_unit: "줄"
method: |
  이 쪽은 게임 배포본의 `FBDataStringUI_en` FlatBuffer를 손대지 않고 그대로 옮긴 것입니다. 열 이름과 값은 원본에 적힌 그대로이며, 계산하거나 단위를 바꾸지 않았습니다.
---

배포본에 적힌 그대로의 기록입니다. 정리하고 이어 붙인 것을 보려면 [갈래별 데이터]({{ '/docs/data-catalog/' | relative_url }})에서 찾아보세요.
