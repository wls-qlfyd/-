---
title: "PcLevel"
layout: data
description: "PcLevel 원본 기록 999줄입니다."
permalink: /docs/data/tables/pc-level/
data_file: "/assets/data/raw/pc-level.json"
data_asset: "FBDataPcLevel"
data_schema: "FBDataPcLevel"
data_rows: 999
data_category: "시스템"
data_fields: ["id","requiredExp"]
data_unit: "줄"
method: |
  이 쪽은 게임 배포본의 `FBDataPcLevel` FlatBuffer를 손대지 않고 그대로 옮긴 것입니다. 열 이름과 값은 원본에 적힌 그대로이며, 계산하거나 단위를 바꾸지 않았습니다.
---

배포본에 적힌 그대로의 기록입니다. 정리하고 이어 붙인 것을 보려면 [갈래별 데이터]({{ '/docs/data-catalog/' | relative_url }})에서 찾아보세요.
