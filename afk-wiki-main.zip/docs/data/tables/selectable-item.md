---
title: "SelectableItem"
layout: data
description: "SelectableItem 원본 기록 12줄입니다."
permalink: /docs/data/tables/selectable-item/
data_file: "/assets/data/raw/selectable-item.json"
data_asset: "FBDataSelectableItem"
data_schema: "FBDataSelectableItem"
data_rows: 12
data_category: "경제·보상"
data_fields: ["id","groupKey","itemId"]
data_unit: "줄"
method: |
  이 쪽은 게임 배포본의 `FBDataSelectableItem` FlatBuffer를 손대지 않고 그대로 옮긴 것입니다. 열 이름과 값은 원본에 적힌 그대로이며, 계산하거나 단위를 바꾸지 않았습니다.
---

배포본에 적힌 그대로의 기록입니다. 정리하고 이어 붙인 것을 보려면 [갈래별 데이터]({{ '/docs/data-catalog/' | relative_url }})에서 찾아보세요.
