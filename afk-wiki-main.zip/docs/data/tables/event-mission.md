---
title: "EventMission"
layout: data
description: "EventMission 원본 기록 2줄입니다."
permalink: /docs/data/tables/event-mission/
data_file: "/assets/data/raw/event-mission.json"
data_asset: "FBDataEventMission"
data_schema: "FBDataEventMission"
data_rows: 2
data_category: "시스템"
data_fields: ["id","groupKey","step","objectiveType","objectiveTarget","objectiveCount"]
data_unit: "줄"
method: |
  이 쪽은 게임 배포본의 `FBDataEventMission` FlatBuffer를 손대지 않고 그대로 옮긴 것입니다. 열 이름과 값은 원본에 적힌 그대로이며, 계산하거나 단위를 바꾸지 않았습니다.
---

배포본에 적힌 그대로의 기록입니다. 정리하고 이어 붙인 것을 보려면 [갈래별 데이터]({{ '/docs/data-catalog/' | relative_url }})에서 찾아보세요.
